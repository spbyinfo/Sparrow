# Sparrow Backend API Specifications

## 📋 Overview
This document details the complete backend API structure for the Sparrow app, organized by navigation pages with top/bottom content splits and all required endpoints.

---

## 🎯 Page 1: BINGO (Home)

### **Top Half (Above Fold)**
**Purpose:** Display active weekly bingo card with real-time scan status

**UI Components:**
- Location selector (Mumbai, India)
- Weekly bingo header with countdown timer
- 3×3 Bingo grid with product SKUs
- Scan button (opens ScanModal)
- Progress indicator (X/9 products scanned)

**Required APIs:**

#### `GET /bingo/active-card`
**Description:** Fetch current week's bingo card for user
```typescript
Request Headers:
{
  Authorization: "Bearer <access_token>",
  "Content-Type": "application/json"
}

Response 200:
{
  cardId: string;              // "card_week_46_2025"
  weekNumber: number;          // 46
  startDate: string;           // "2025-11-10T00:00:00Z"
  endDate: string;             // "2025-11-16T23:59:59Z"
  location: string;            // "mumbai"
  products: [
    {
      id: string;              // "prod_123"
      sku: string;             // "SKU8734"
      position: number;        // 0-8 (grid position)
      name: string;            // "Coca-Cola 500ml"
      category: string;        // "Soft Drink"
      brandLogo: string;       // Image URL
      image3D: string;         // 3D product image URL
      plasticType: string;     // "PETE #1"
      description: string;
      recyclable: boolean;
      scannedAt?: string;      // ISO timestamp if scanned
      credits: number;         // 50
    },
    // ... 8 more products
  ];
  totalCredits: number;        // 450 (sum of all product credits)
  scannedCount: number;        // 3
  completionBonus: number;     // 100 (bonus for completing all 9)
  isComplete: boolean;
}
```

#### `POST /bingo/scan`
**Description:** Register a product scan (via barcode/QR)
```typescript
Request:
{
  cardId: string;              // "card_week_46_2025"
  sku: string;                 // "SKU8734"
  scannedAt: string;           // ISO timestamp
  location?: {
    lat: number;
    lng: number;
  }
}

Response 200:
{
  success: boolean;
  product: {
    id: string;
    sku: string;
    name: string;
    credits: number;
  };
  creditsEarned: number;       // 50
  newTotalCredits: number;     // User's new credit balance
  scannedCount: number;        // 4 (updated count)
  isCardComplete: boolean;     // false
  bonusEarned?: number;        // 100 if card just completed
}

Response 400 (Already Scanned):
{
  error: "ALREADY_SCANNED",
  message: "This product was already scanned"
}

Response 404 (Invalid SKU):
{
  error: "INVALID_SKU",
  message: "This SKU is not in your current bingo card"
}
```

### **Bottom Half (Below Fold)**
**Purpose:** Past bingo cards history and completion status

**UI Components:**
- "Past Bingo Cards" section header
- Scrollable list of previous weeks
- Completion status badges
- Credits earned summary

**Required APIs:**

#### `GET /bingo/history`
**Description:** Fetch user's past bingo cards
```typescript
Request Query Params:
{
  limit?: number;              // Default 10
  offset?: number;             // For pagination
}

Response 200:
{
  cards: [
    {
      cardId: string;
      weekNumber: number;
      startDate: string;
      endDate: string;
      location: string;
      scannedCount: number;    // 9
      totalProducts: number;   // 9
      isComplete: boolean;     // true
      creditsEarned: number;   // 550 (including bonus)
      completedAt?: string;
    },
    // ... more cards
  ];
  totalCards: number;
  hasMore: boolean;
}
```

---

## 💰 Page 2: CREDITS

### **Top Half (Above Fold)**
**Purpose:** Display user's credit balance and redemption options

**UI Components:**
- Large credit balance display (animated number)
- Imperial gold styling
- "Redeem Credits" CTA button
- Credit value equivalency (e.g., "= ₹450")
- Achievement badges

**Required APIs:**

#### `GET /credits/balance`
**Description:** Get current credit balance and stats
```typescript
Response 200:
{
  userId: string;
  balance: number;             // 2,450
  currency: string;            // "credits"
  valueInINR: number;          // 2450 (1 credit = ₹1)
  lifetimeEarned: number;      // 5,600
  lifetimeRedeemed: number;    // 3,150
  rank: string;                // "Gold Recycler"
  nextRankAt: number;          // 5000 credits
  achievements: [
    {
      id: string;
      name: string;            // "First Scan"
      icon: string;            // Icon/badge URL
      unlockedAt: string;
    }
  ]
}
```

#### `GET /credits/redemption-options`
**Description:** Available redemption methods
```typescript
Response 200:
{
  options: [
    {
      id: string;              // "upi_transfer"
      type: "upi" | "bank" | "voucher" | "donation";
      name: string;            // "UPI Transfer"
      description: string;
      minCredits: number;      // 100
      maxCredits: number;      // 10000
      fee: number;             // 0 (percentage)
      icon: string;
      enabled: boolean;
      processingTime: string;  // "Instant"
    },
    {
      id: "amazon_voucher",
      type: "voucher",
      name: "Amazon Gift Card",
      minCredits: 500,
      icon: "...",
      enabled: true,
      processingTime: "24 hours"
    }
    // ... more options
  ]
}
```

#### `POST /credits/redeem`
**Description:** Redeem credits
```typescript
Request:
{
  optionId: string;            // "upi_transfer"
  amount: number;              // 1000 credits
  details: {
    // For UPI:
    upiId?: string;            // "user@paytm"
    
    // For bank:
    accountNumber?: string;
    ifscCode?: string;
    accountHolderName?: string;
    
    // For voucher:
    email?: string;
  }
}

Response 200:
{
  success: boolean;
  transactionId: string;       // "txn_123abc"
  amountRedeemed: number;      // 1000
  newBalance: number;          // 1450
  estimatedDelivery: string;   // "Instant" or timestamp
  status: "pending" | "processing" | "completed";
}

Response 400:
{
  error: "INSUFFICIENT_CREDITS" | "INVALID_DETAILS" | "BELOW_MINIMUM",
  message: string;
}
```

### **Bottom Half (Below Fold)**
**Purpose:** Transaction history and earning opportunities

**UI Components:**
- "Transaction History" section
- Scrollable list of credit transactions
- Filter buttons (All, Earned, Redeemed)
- "Ways to Earn More" suggestions

**Required APIs:**

#### `GET /credits/transactions`
**Description:** Fetch transaction history
```typescript
Request Query Params:
{
  type?: "all" | "earned" | "redeemed";
  limit?: number;              // Default 20
  offset?: number;
}

Response 200:
{
  transactions: [
    {
      id: string;
      type: "earned" | "redeemed" | "bonus" | "refund";
      amount: number;          // +50 or -1000
      description: string;     // "Scanned Coca-Cola 500ml"
      timestamp: string;
      status: "completed" | "pending" | "failed";
      relatedTo?: {
        type: "bingo_scan" | "redemption" | "referral";
        id: string;
      }
    },
    // ... more transactions
  ];
  totalCount: number;
  hasMore: boolean;
}
```

#### `GET /credits/earning-opportunities`
**Description:** Suggest ways to earn more credits
```typescript
Response 200:
{
  opportunities: [
    {
      id: string;
      title: string;           // "Complete this week's bingo"
      description: string;
      potentialCredits: number;// 450
      action: string;          // "Go to Bingo"
      actionUrl: string;       // "/bingo"
      icon: string;
      priority: number;        // 1 (higher = show first)
    },
    {
      id: "refer_friend",
      title: "Refer a friend",
      potentialCredits: 200,
      action: "Share invite",
      // ...
    }
  ]
}
```

---

## 🎫 Page 3: PASS (Partner Businesses)

### **Top Half (Above Fold)**
**Purpose:** Display nearby partner businesses with available surplus items

**UI Components:**
- Location display with change option
- Search/filter bar
- Featured partners carousel
- TooGoodToGo-style "Surprise Bags" grid
- Real-time availability indicators

**Required APIs:**

#### `GET /pass/partners`
**Description:** Get partner businesses near user's location
```typescript
Request Query Params:
{
  location: string;            // "mumbai" or lat,lng
  radius?: number;             // km, default 5
  category?: string;           // "restaurant" | "bakery" | "grocery" | "all"
  availability?: boolean;      // Only show with items available
  limit?: number;
  offset?: number;
}

Response 200:
{
  partners: [
    {
      id: string;              // "partner_123"
      name: string;            // "Fresh Harvest Bakery"
      category: string;        // "bakery"
      logo: string;            // Logo URL
      coverImage: string;
      rating: number;          // 4.8
      reviewCount: number;     // 234
      distance: number;        // 1.2 km
      location: {
        address: string;
        city: string;
        lat: number;
        lng: number;
      };
      openingHours: {
        open: string;          // "09:00"
        close: string;         // "21:00"
        timezone: string;
      };
      isOpen: boolean;
      availableItems: number;  // 5 surprise bags
      tags: string[];          // ["Veg", "Organic", "Gluten-Free"]
    },
    // ... more partners
  ];
  totalCount: number;
  hasMore: boolean;
  filters: {
    categories: string[];
    availableTags: string[];
  }
}
```

#### `GET /pass/inventory/:partnerId`
**Description:** Get available items from specific partner
```typescript
Response 200:
{
  partnerId: string;
  partnerName: string;
  items: [
    {
      id: string;              // "item_789"
      type: "surprise_bag" | "specific_item";
      name: string;            // "Bakery Surprise Bag"
      description: string;
      originalPrice: number;   // 300
      discountedPrice: number; // 99
      savingsPercent: number;  // 67%
      quantity: number;        // 3 available
      availableFrom: string;   // "18:00" (pickup time)
      availableUntil: string;  // "21:00"
      image: string;
      estimatedValue: string;  // "Worth ₹300-400"
      contents?: string[];     // ["Bread", "Pastries", "Cookies"]
      dietaryInfo: string[];   // ["Vegetarian", "Contains Gluten"]
    },
    // ... more items
  ];
  pickupInstructions: string;
  cancellationPolicy: string;
}
```

#### `POST /pass/reserve`
**Description:** Reserve a surprise bag or item
```typescript
Request:
{
  partnerId: string;
  itemId: string;
  quantity: number;            // 1
  pickupTime: string;          // ISO timestamp
  paymentMethod: "credits" | "card" | "upi";
  paymentDetails?: {
    // If paying with credits:
    creditsToUse?: number;
    
    // If paying with card/UPI:
    // ... payment gateway details
  }
}

Response 200:
{
  success: boolean;
  reservationId: string;       // "res_abc123"
  partnerId: string;
  partnerName: string;
  items: [
    {
      itemId: string;
      name: string;
      quantity: number;
      price: number;
    }
  ];
  totalAmount: number;         // 99
  creditsUsed?: number;        // 50
  pickupCode: string;          // "ABC123" (show to partner)
  pickupTime: string;
  pickupWindow: string;        // "18:00 - 21:00"
  pickupAddress: string;
  pickupInstructions: string;
  expiresAt: string;
  cancellationDeadline: string;
  status: "confirmed" | "pending_payment";
}

Response 400:
{
  error: "ITEM_UNAVAILABLE" | "INSUFFICIENT_CREDITS" | "INVALID_PICKUP_TIME",
  message: string;
}
```

### **Bottom Half (Below Fold)**
**Purpose:** User's reservations and past pickups

**UI Components:**
- "Your Reservations" section
- Active reservations with pickup codes
- Past pickups history
- "Suggest a Business" CTA

**Required APIs:**

#### `GET /pass/reservations`
**Description:** Get user's reservations
```typescript
Request Query Params:
{
  status?: "active" | "past" | "cancelled" | "all";
  limit?: number;
  offset?: number;
}

Response 200:
{
  reservations: [
    {
      id: string;
      partnerId: string;
      partnerName: string;
      partnerLogo: string;
      items: [
        {
          name: string;
          quantity: number;
          price: number;
        }
      ];
      pickupCode: string;      // "ABC123"
      pickupTime: string;
      pickupWindow: string;
      pickupAddress: string;
      totalAmount: number;
      creditsUsed?: number;
      status: "confirmed" | "picked_up" | "cancelled" | "expired";
      createdAt: string;
      pickedUpAt?: string;
    },
    // ... more reservations
  ];
  activeCount: number;
  totalCount: number;
  hasMore: boolean;
}
```

#### `POST /pass/cancel-reservation`
**Description:** Cancel a reservation
```typescript
Request:
{
  reservationId: string;
  reason?: string;
}

Response 200:
{
  success: boolean;
  reservationId: string;
  refundAmount: number;        // If applicable
  refundedCredits?: number;
  message: string;
}
```

#### `POST /pass/suggest-business`
**Description:** Suggest a new partner business
```typescript
Request:
{
  businessName: string;
  category: string;
  address: string;
  city: string;
  contactPerson?: string;
  phone?: string;
  email?: string;
  reason: string;              // Why should they partner?
}

Response 200:
{
  success: boolean;
  suggestionId: string;
  message: string;             // "Thanks! We'll review this business."
}
```

---

## 👤 Page 4: PROFILE

### **Top Half (Above Fold)**
**Purpose:** User profile info, KYC status, and key stats

**UI Components:**
- Profile avatar (with edit option)
- Name, email, phone
- Location badge
- KYC verification badge
- Key stats cards (Total Credits Earned, Items Scanned, CO2 Saved)
- Edit Profile button

**Required APIs:**

#### `GET /profile/me`
**Description:** Get authenticated user's profile
```typescript
Response 200:
{
  userId: string;
  name: string;
  email: string;
  phone: string;              // "+91XXXXXXXXXX"
  avatar?: string;            // Avatar image URL
  location: {
    city: string;             // "Mumbai"
    region: string;           // "Maharashtra"
    country: string;          // "India"
  };
  kycStatus: "not_started" | "pending" | "verified" | "rejected";
  kycDetails?: {
    aadhaar: string;          // Masked: "XXXX XXXX 1234"
    pan: string;              // Masked: "XXXXX1234X"
    verifiedAt?: string;
    rejectionReason?: string;
  };
  stats: {
    totalCreditsEarned: number;
    totalItemsScanned: number;
    bingoCardsCompleted: number;
    co2Saved: number;         // kg
    plasticRecycled: number;  // kg
    joinedAt: string;
    rank: string;             // "Gold Recycler"
  };
  preferences: {
    notifications: boolean;
    emailUpdates: boolean;
    language: string;         // "en" | "hi"
  };
  accountStatus: "active" | "suspended" | "deleted";
  isGuest: boolean;
}
```

#### `PUT /profile/update`
**Description:** Update profile information
```typescript
Request:
{
  name?: string;
  email?: string;
  phone?: string;
  avatar?: string;            // Base64 or URL
  location?: {
    city: string;
  };
  preferences?: {
    notifications?: boolean;
    emailUpdates?: boolean;
    language?: string;
  };
}

Response 200:
{
  success: boolean;
  user: {
    // ... updated user object (same as GET /profile/me)
  }
}
```

#### `POST /profile/kyc/submit`
**Description:** Submit KYC documents
```typescript
Request:
{
  aadhaarNumber: string;      // 12 digits
  panNumber: string;          // 10 chars (ABCDE1234F)
  documents: {
    aadhaarFront: string;     // Base64 image
    aadhaarBack?: string;
    panCard: string;
  };
  consentGiven: boolean;      // Must be true
}

Response 200:
{
  success: boolean;
  kycId: string;
  status: "pending";          // Moves to "verified" after review
  message: string;
  estimatedReviewTime: string;// "24-48 hours"
}

Response 400:
{
  error: "INVALID_AADHAAR" | "INVALID_PAN" | "DOCUMENTS_REQUIRED",
  message: string;
}
```

### **Bottom Half (Below Fold)**
**Purpose:** Settings, logout, danger zone

**UI Components:**
- Settings sections:
  - Notifications
  - Privacy
  - Language
  - Help & Support
  - Terms & Privacy Policy
- Logout button
- Delete Account (danger zone)

**Required APIs:**

#### `GET /profile/settings`
**Description:** Get all user settings
```typescript
Response 200:
{
  notifications: {
    push: boolean;
    email: boolean;
    sms: boolean;
    bingoReminders: boolean;
    passAlerts: boolean;
  };
  privacy: {
    profileVisibility: "public" | "private";
    showStats: boolean;
    dataSharing: boolean;
  };
  language: string;
  theme: "light" | "dark" | "auto";
}
```

#### `PUT /profile/settings`
**Description:** Update settings
```typescript
Request:
{
  notifications?: { ... };
  privacy?: { ... };
  language?: string;
  theme?: string;
}

Response 200:
{
  success: boolean;
  settings: {
    // ... updated settings
  }
}
```

#### `POST /profile/logout`
**Description:** Logout user (invalidate session)
```typescript
Response 200:
{
  success: boolean;
  message: "Logged out successfully"
}
```

#### `DELETE /profile/delete-account`
**Description:** Permanently delete user account
```typescript
Request:
{
  password: string;           // Confirm with password
  reason?: string;
  confirmPhrase: string;      // Must match "DELETE MY ACCOUNT"
}

Response 200:
{
  success: boolean;
  message: string;
  scheduledDeletionDate: string; // 30 days grace period
}
```

---

## 🔐 Additional Auth Endpoints

#### `POST /auth/signup`
**Description:** Create new user account
```typescript
Request:
{
  name: string;
  email: string;
  phone: string;
  password: string;
  location: string;           // "mumbai"
  referralCode?: string;
}

Response 200:
{
  success: boolean;
  userId: string;
  accessToken: string;
  refreshToken: string;
  user: {
    // ... user object
  };
  message: string;
}
```

#### `POST /auth/signin`
**Description:** Sign in existing user
```typescript
Request:
{
  email: string;
  password: string;
}

Response 200:
{
  success: boolean;
  accessToken: string;
  refreshToken: string;
  user: {
    // ... user object
  }
}

Response 401:
{
  error: "INVALID_CREDENTIALS",
  message: "Email or password is incorrect"
}
```

#### `POST /auth/guest`
**Description:** Create temporary guest session
```typescript
Request:
{
  deviceId: string;           // Unique device identifier
  location?: string;
}

Response 200:
{
  success: boolean;
  guestId: string;
  accessToken: string;
  expiresAt: string;
  limitations: {
    canScan: boolean;         // false
    canRedeemCredits: boolean;// false
    message: string;
  }
}
```

#### `POST /auth/convert-guest`
**Description:** Convert guest to full user
```typescript
Request:
{
  guestId: string;
  name: string;
  email: string;
  phone: string;
  password: string;
}

Response 200:
{
  success: boolean;
  userId: string;
  accessToken: string;
  refreshToken: string;
  migratedData: {
    viewedPartners: number;
    // Guest data that was migrated
  }
}
```

---

## 📊 Data Models

### User
```typescript
{
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  passwordHash: string;
  location: string;
  kycStatus: string;
  kycDetails?: object;
  preferences: object;
  accountStatus: string;
  isGuest: boolean;
  createdAt: string;
  updatedAt: string;
  lastLoginAt: string;
}
```

### BingoCard
```typescript
{
  id: string;
  userId: string;
  weekNumber: number;
  startDate: string;
  endDate: string;
  location: string;
  products: string[];         // Array of product IDs
  scannedProducts: string[];  // Array of scanned product IDs
  completedAt?: string;
  isActive: boolean;
  createdAt: string;
}
```

### Product
```typescript
{
  id: string;
  sku: string;
  name: string;
  category: string;
  brand: string;
  brandLogo: string;
  image3D: string;
  plasticType: string;
  description: string;
  recyclable: boolean;
  credits: number;
  weight?: number;            // grams
  volume?: number;            // ml
  barcode?: string;
  availability: string[];     // Array of location IDs
  createdAt: string;
}
```

### CreditTransaction
```typescript
{
  id: string;
  userId: string;
  type: "earned" | "redeemed" | "bonus" | "refund";
  amount: number;
  description: string;
  status: string;
  relatedType?: string;
  relatedId?: string;
  balanceBefore: number;
  balanceAfter: number;
  createdAt: string;
}
```

### Partner
```typescript
{
  id: string;
  name: string;
  category: string;
  logo: string;
  coverImage: string;
  description: string;
  rating: number;
  reviewCount: number;
  location: object;
  openingHours: object;
  contactInfo: object;
  tags: string[];
  isActive: boolean;
  joinedAt: string;
  createdAt: string;
}
```

### Reservation
```typescript
{
  id: string;
  userId: string;
  partnerId: string;
  items: array;
  pickupCode: string;
  pickupTime: string;
  pickupWindow: string;
  totalAmount: number;
  creditsUsed?: number;
  status: string;
  paymentStatus: string;
  paymentMethod: string;
  createdAt: string;
  pickedUpAt?: string;
  cancelledAt?: string;
  expiresAt: string;
}
```

---

## 🔄 Real-Time Updates (WebSocket/SSE)

For real-time features, consider implementing:

### Bingo Card Updates
- Subscribe to `/ws/bingo/:cardId`
- Receive updates when other products are scanned
- Show live progress to user

### Pass Availability
- Subscribe to `/ws/pass/partner/:partnerId`
- Receive updates when items become available/unavailable
- Update UI in real-time

### Credit Balance
- Subscribe to `/ws/credits/:userId`
- Receive updates when credits are earned/spent
- Show live balance updates

---

## 🚨 Error Handling Standards

All endpoints should return consistent error format:

```typescript
{
  error: string;              // Error code (SNAKE_CASE)
  message: string;            // Human-readable message
  details?: object;           // Additional error context
  timestamp: string;          // ISO timestamp
  requestId: string;          // For debugging
}
```

Common HTTP Status Codes:
- **200**: Success
- **201**: Created
- **400**: Bad Request (validation error)
- **401**: Unauthorized (invalid/missing token)
- **403**: Forbidden (authenticated but not allowed)
- **404**: Not Found
- **409**: Conflict (e.g., already scanned)
- **429**: Too Many Requests (rate limit)
- **500**: Internal Server Error

---

## 🔒 Authentication

All authenticated endpoints require:
```
Authorization: Bearer <access_token>
```

Tokens expire after 24 hours. Use refresh token to get new access token:
```typescript
POST /auth/refresh
{
  refreshToken: string;
}

Response 200:
{
  accessToken: string;
  refreshToken: string;
}
```

---

## 📈 Rate Limiting

- **Scanning**: 30 requests per minute per user
- **Redemption**: 5 requests per hour per user
- **Reservation**: 10 requests per minute per user
- **Profile Updates**: 20 requests per hour per user
- **General API**: 100 requests per minute per user

---

## 🌍 Localization

All text responses should support localization:
- Include `Accept-Language` header in requests
- Supported languages: `en` (English), `hi` (Hindi)
- Return localized strings for messages, descriptions

---

## 📱 Mobile-Specific Considerations

- Image URLs should support query params for resizing: `?w=300&h=300&q=80`
- Use CDN for all static assets
- Support offline mode where possible (cache responses)
- Implement exponential backoff for retries
- Compress responses with gzip

---

**Document Version:** 1.0  
**Last Updated:** November 12, 2025  
**Contact:** Backend Team Lead
