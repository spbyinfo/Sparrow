# Sparrow Documentation

This folder contains feature-specific documentation for developers and stakeholders.

## 📚 Documentation Index

### Feature Guides
- **[RESERVATION_SYSTEM.md](./RESERVATION_SYSTEM.md)** - Partner reservation system with confirmation codes
- **[B2B_SETUP.md](./B2B_SETUP.md)** - Brand partner analytics and setup
- **[PERISHABLE_SERVICES.md](./PERISHABLE_SERVICES.md)** - Future feature ideas and concepts

### Technical References
- **[DATA_MODEL.md](./DATA_MODEL.md)** - Database schema and data structures
- **[ATTRIBUTIONS.md](./ATTRIBUTIONS.md)** - Third-party credits and licenses

---

## 🎯 Quick Links

**For Developers:**
- Start with [/guidelines/Guidelines.md](../guidelines/Guidelines.md) for development rules
- Review [DATA_MODEL.md](./DATA_MODEL.md) for database structure
- Check main [README.md](../README.md) for project setup

**For Product/Business:**
- [RESERVATION_SYSTEM.md](./RESERVATION_SYSTEM.md) - How reservations work
- [B2B_SETUP.md](./B2B_SETUP.md) - Partner onboarding
- [PERISHABLE_SERVICES.md](./PERISHABLE_SERVICES.md) - Future ideas

---

**Last Updated:** November 2024
