# Attributions

## Third-Party Components & Assets

### UI Components
This project includes components from [shadcn/ui](https://ui.shadcn.com/) used under [MIT license](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

### Images
This project includes photos from [Unsplash](https://unsplash.com) used under [Unsplash License](https://unsplash.com/license).

### Icons
This project uses [Lucide Icons](https://lucide.dev/) under [ISC License](https://github.com/lucide-icons/lucide/blob/main/LICENSE).

---

© 2024 Sparrow Team. All rights reserved.
