# 🐦 Sparrow

**Gamified waste collection app for India — Play bingo, recycle right, earn green credits.**

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone)

---

## Overview

Sparrow is a mobile-first Progressive Web App (PWA) that gamifies waste recycling through weekly bingo challenges. Users scan product SKUs, complete bingo cards, and earn green credits redeemable at partner businesses.

**Key Features:**
- 🎯 3×3 weekly bingo cards with product SKUs
- 📸 Direct tap-to-scan product scanning
- 💰 Green credits reward system
- 🎫 Pass system with partner business reservations (TooGoodToGo-style)
- 🔐 Full authentication with guest mode and eKYC verification
- 📱 PWA with offline support and native app feel

---

## Tech Stack

- **Frontend:** React 18, TypeScript, Vite
- **Styling:** Tailwind CSS v4
- **UI Components:** ShadCN/UI, Radix UI
- **Backend:** Supabase (Postgres, Auth, Edge Functions)
- **Deployment:** Vercel
- **Icons:** Lucide React

---

## Quick Start

### Prerequisites
- Node.js 18+
- npm 9+

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd sparrow

# Install dependencies
npm install

# Start development server
npm run dev
```

Visit `http://localhost:5173`

### Build for Production

```bash
npm run build
npm run preview
```

---

## Deployment

### Deploy to Vercel

1. **Connect GitHub repository to Vercel** or upload project folder
2. **Framework Preset:** Vite (auto-detected)
3. **Add Environment Variables:**
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_anon_key
   ```
4. **Deploy**

### Environment Variables

Required in production:
- `VITE_SUPABASE_URL` - Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Supabase anonymous key (public)

Backend requires (server-side only):
- `SUPABASE_SERVICE_ROLE_KEY` - Service role key (never expose to frontend)

---

## Project Structure

```
sparrow/
├── App.tsx                    # Main app component
├── components/                # React components
│   ├── AuthChoice.tsx        # Authentication flow
│   ├── BingoCard.tsx         # 3×3 bingo game
│   ├── MyPass.tsx            # Partner reservations
│   ├── UserProfile.tsx       # User settings
│   └── ui/                   # ShadCN/UI components
├── src/
│   └── main.tsx              # App entry point
├── styles/
│   └── globals.css           # Tailwind + design tokens
├── utils/
│   ├── api.ts                # API client
│   └── supabase/             # Supabase config
├── supabase/
│   └── functions/server/     # Edge functions (Hono server)
├── public/
│   ├── manifest.json         # PWA manifest
│   └── sw.js                 # Service worker
└── guidelines/
    └── Guidelines.md         # Development guidelines
```

---

## Development Guidelines

**All development rules, design system, and best practices are in:**

📄 **[guidelines/Guidelines.md](./guidelines/Guidelines.md)**

This includes:
- Brand identity and color palette
- Mobile-first responsive design rules
- Typography and spacing systems
- Component guidelines
- Accessibility standards
- India-specific features (KYC, phone validation, etc.)

---

## Feature Documentation

Detailed feature specifications in `/docs`:

- **[RESERVATION_SYSTEM.md](./docs/RESERVATION_SYSTEM.md)** - Partner reservation flow with confirmation codes
- **[B2B_SETUP.md](./docs/B2B_SETUP.md)** - Setting up partner businesses and analytics
- **[PERISHABLE_SERVICES.md](./docs/PERISHABLE_SERVICES.md)** - Future feature ideas and concepts
- **[DATA_MODEL.md](./docs/DATA_MODEL.md)** - Database schema and data structures
- **[ATTRIBUTIONS.md](./docs/ATTRIBUTIONS.md)** - Third-party credits and licenses

---

## Mobile Installation (PWA)

### iPhone (Safari)
1. Visit app URL in Safari
2. Tap Share → "Add to Home Screen"
3. App appears as icon on home screen

### Android (Chrome)
1. Visit app URL in Chrome
2. Tap menu → "Install app"
3. App appears as icon in app drawer

---

## Design Philosophy

**Gaudí × Wes Anderson whimsy with Indian cultural colors**

### Color Palette
- 🟧 **Saffron** `#ff9933` - Primary (credits/rewards)
- 🟩 **Nature Green** `#059669` - Secondary (success)
- 🟨 **Imperial Gold** `#ffd700` - Accent (achievements)
- 🟥 **Royal Red** `#dc143c` - Destructive (alerts)
- 🟦 **Divine Blue** `#4169e1` - Utility

### Key Principles
- **Border Radius:** 1.5rem (24px) for organic curves
- **Touch Targets:** 48px minimum (WCAG AAA)
- **Typography:** 16px base for mobile readability
- **Mobile-First:** Designed for iPhone SE → Pro Max

---

## Backend Architecture

Sparrow uses a three-tier architecture:

**Frontend → Server (Hono) → Database (Postgres)**

### Supabase Components
1. **Database:** Key-value store + custom tables
2. **Auth:** Email/password with guest mode
3. **Edge Functions:** Hono web server at `/supabase/functions/server/`
4. **Storage:** Private buckets for file uploads (if needed)

### API Routes
Server runs at: `https://{projectId}.supabase.co/functions/v1/make-server-efcc1648/`

Key endpoints:
- `POST /reservations` - Create partner reservation
- `GET /reservations/:userId` - Get user reservations
- `DELETE /reservations/:id` - Cancel reservation

See [RESERVATION_SYSTEM.md](./docs/RESERVATION_SYSTEM.md) for full API documentation.

---

## Scripts

```bash
# Development
npm run dev              # Start dev server (localhost:5173)
npm run build            # Build for production
npm run preview          # Preview production build

# Environment-specific builds
npm run dev:staging      # Staging environment
npm run dev:preprod      # Pre-production
npm run dev:production   # Production
```

---

## Contributing

1. Follow the **[Guidelines.md](./guidelines/Guidelines.md)** strictly
2. Test on mobile devices (iPhone SE minimum)
3. Ensure accessibility (WCAG AA minimum)
4. Keep touch targets ≥ 48px
5. Use the defined color palette only

---

## License

© 2024 Sparrow Team. All rights reserved.

---

## Support

- **Development Issues:** Check [Guidelines.md](./guidelines/Guidelines.md)
- **Build Errors:** Review `package.json` dependencies
- **Backend Issues:** Check Supabase dashboard logs
- **Deployment Issues:** Review Vercel deployment logs

---

**Built with ♻️ for a sustainable India** 🐦🌍💚