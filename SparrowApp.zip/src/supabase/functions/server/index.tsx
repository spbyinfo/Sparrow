import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// ============================================
// PRODUCT ENDPOINTS
// ============================================

// Get all products
app.get("/make-server-efcc1648/products", async (c) => {
  try {
    const products = await kv.getByPrefix("product:");
    return c.json({ success: true, products });
  } catch (error) {
    console.log("Error fetching products:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get single product by SKU
app.get("/make-server-efcc1648/products/:sku", async (c) => {
  try {
    const sku = c.req.param("sku");
    const product = await kv.get(`product:${sku}`);
    
    if (!product) {
      return c.json({ success: false, error: "Product not found" }, 404);
    }
    
    return c.json({ success: true, product });
  } catch (error) {
    console.log("Error fetching product:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Seed products (for initial setup)
app.post("/make-server-efcc1648/products/seed", async (c) => {
  try {
    const products = await c.req.json();
    
    for (const product of products) {
      await kv.set(`product:${product.sku}`, product);
    }
    
    return c.json({ success: true, message: `Seeded ${products.length} products` });
  } catch (error) {
    console.log("Error seeding products:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// SCAN TRACKING ENDPOINTS
// ============================================

// Record a new scan
app.post("/make-server-efcc1648/scans", async (c) => {
  try {
    const body = await c.req.json();
    const { sku, city, area, pincode, scanMethod, credits } = body;
    
    // Validation
    if (!sku || !city || !area || !pincode) {
      return c.json({ 
        success: false, 
        error: "Missing required fields: sku, city, area, pincode" 
      }, 400);
    }
    
    // Get product to extract brand info
    const product = await kv.get(`product:${sku}`);
    if (!product) {
      return c.json({ success: false, error: "Product not found" }, 404);
    }
    
    const brandId = product.brandId || product.brand.toLowerCase().replace(/\s+/g, '-');
    
    // Generate scan ID and timestamp
    const scanId = crypto.randomUUID();
    const timestamp = Date.now();
    const date = new Date(timestamp);
    const dateStr = date.toISOString().split('T')[0]; // YYYY-MM-DD
    const timeStr = date.toTimeString().split(' ')[0].substring(0, 5); // HH:mm
    const hour = date.getHours();
    
    // Create scan event (privacy-first, no user ID)
    const scanEvent = {
      scanId,
      sku,
      timestamp,
      date: dateStr,
      time: timeStr,
      city,
      area,
      pincode,
      scanMethod: scanMethod || 'camera',
      credits: credits || product.credits || 0,
    };
    
    // Store scan record
    await kv.set(`scan:${scanId}`, scanEvent);
    
    // Create indexes for efficient querying
    await kv.set(`scan:sku:${sku}:${timestamp}`, scanId);
    await kv.set(`scan:date:${dateStr}:${timestamp}`, scanId);
    await kv.set(`scan:brand:${brandId}:${timestamp}`, scanId);
    
    // Update daily aggregated stats
    const statsKey = `stats:brand:${brandId}:${dateStr}`;
    const existingStats = await kv.get(statsKey) || {
      date: dateStr,
      totalScans: 0,
      uniqueAreas: [],
      scansByCityMap: {},
      scansByHourMap: {},
      totalCredits: 0,
    };
    
    existingStats.totalScans += 1;
    existingStats.totalCredits += scanEvent.credits;
    
    if (!existingStats.uniqueAreas.includes(area)) {
      existingStats.uniqueAreas.push(area);
    }
    
    existingStats.scansByCityMap[city] = (existingStats.scansByCityMap[city] || 0) + 1;
    existingStats.scansByHourMap[hour] = (existingStats.scansByHourMap[hour] || 0) + 1;
    
    await kv.set(statsKey, existingStats);
    
    return c.json({ 
      success: true, 
      scanId,
      credits: scanEvent.credits,
      message: "Scan recorded successfully" 
    });
  } catch (error) {
    console.log("Error recording scan:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// B2B ANALYTICS ENDPOINTS
// ============================================

// ============================================
// RESERVATION ENDPOINTS
// ============================================

// Generate a unique confirmation code
function generateConfirmationCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed confusing chars: I, O, 0, 1
  let code = 'SPARROW-';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// Create a new reservation
app.post("/make-server-efcc1648/reservations", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, businessId, businessName, userName, userEmail, userPhone } = body;
    
    // Validation
    if (!userId || !businessId || !businessName) {
      return c.json({ 
        success: false, 
        error: "Missing required fields: userId, businessId, businessName" 
      }, 400);
    }
    
    // Check if business has available inventory
    const inventoryKey = `inventory:${businessId}`;
    const inventory = await kv.get(inventoryKey);
    
    if (!inventory || inventory.available <= 0) {
      return c.json({ 
        success: false, 
        error: "No services available at this business" 
      }, 400);
    }
    
    // Generate unique confirmation code
    const confirmationCode = generateConfirmationCode();
    const reservationId = crypto.randomUUID();
    const timestamp = Date.now();
    const date = new Date(timestamp);
    const dateStr = date.toISOString().split('T')[0]; // YYYY-MM-DD
    const timeStr = date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    
    // Create reservation record
    const reservation = {
      id: reservationId,
      userId,
      businessId,
      businessName,
      userName: userName || 'Guest User',
      userEmail: userEmail || '',
      userPhone: userPhone || '',
      confirmationCode,
      status: 'active', // active, redeemed, cancelled
      createdAt: timestamp,
      createdDate: dateStr,
      createdTime: timeStr,
      redeemedAt: null,
      cancelledAt: null,
    };
    
    // Store reservation
    await kv.set(`reservation:${reservationId}`, reservation);
    
    // Create indexes for efficient querying
    await kv.set(`reservation:user:${userId}:${timestamp}`, reservationId);
    await kv.set(`reservation:business:${businessId}:${timestamp}`, reservationId);
    await kv.set(`reservation:code:${confirmationCode}`, reservationId);
    
    // Decrement inventory
    inventory.available -= 1;
    inventory.reserved = (inventory.reserved || 0) + 1;
    await kv.set(inventoryKey, inventory);
    
    console.log(`Reservation created: ${confirmationCode} for ${businessName}`);
    
    return c.json({ 
      success: true, 
      reservation,
      message: "Reservation created successfully" 
    });
  } catch (error) {
    console.log("Error creating reservation:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get user's reservations
app.get("/make-server-efcc1648/reservations/user/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    
    // Get all reservation IDs for this user
    const reservationIds = await kv.getByPrefix(`reservation:user:${userId}`);
    
    // Fetch full reservation details
    const reservations = await Promise.all(
      reservationIds.map(async (id: string) => {
        return await kv.get(`reservation:${id}`);
      })
    );
    
    // Filter out nulls and sort by date (newest first)
    const validReservations = reservations
      .filter(r => r !== null)
      .sort((a, b) => b.createdAt - a.createdAt);
    
    return c.json({ 
      success: true, 
      reservations: validReservations 
    });
  } catch (error) {
    console.log("Error fetching user reservations:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get reservation by confirmation code
app.get("/make-server-efcc1648/reservations/code/:code", async (c) => {
  try {
    const code = c.req.param("code");
    
    // Get reservation ID from code
    const reservationId = await kv.get(`reservation:code:${code}`);
    
    if (!reservationId) {
      return c.json({ 
        success: false, 
        error: "Reservation not found" 
      }, 404);
    }
    
    // Get full reservation
    const reservation = await kv.get(`reservation:${reservationId}`);
    
    return c.json({ 
      success: true, 
      reservation 
    });
  } catch (error) {
    console.log("Error fetching reservation by code:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Mark reservation as redeemed (for manual reconciliation)
app.post("/make-server-efcc1648/reservations/:id/redeem", async (c) => {
  try {
    const reservationId = c.req.param("id");
    
    const reservation = await kv.get(`reservation:${reservationId}`);
    
    if (!reservation) {
      return c.json({ 
        success: false, 
        error: "Reservation not found" 
      }, 404);
    }
    
    if (reservation.status === 'redeemed') {
      return c.json({ 
        success: false, 
        error: "Reservation already redeemed" 
      }, 400);
    }
    
    // Update reservation
    reservation.status = 'redeemed';
    reservation.redeemedAt = Date.now();
    
    await kv.set(`reservation:${reservationId}`, reservation);
    
    // Update inventory counts
    const inventoryKey = `inventory:${reservation.businessId}`;
    const inventory = await kv.get(inventoryKey);
    if (inventory) {
      inventory.reserved = Math.max(0, (inventory.reserved || 0) - 1);
      inventory.redeemed = (inventory.redeemed || 0) + 1;
      await kv.set(inventoryKey, inventory);
    }
    
    return c.json({ 
      success: true, 
      reservation,
      message: "Reservation marked as redeemed" 
    });
  } catch (error) {
    console.log("Error redeeming reservation:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Cancel reservation
app.post("/make-server-efcc1648/reservations/:id/cancel", async (c) => {
  try {
    const reservationId = c.req.param("id");
    
    const reservation = await kv.get(`reservation:${reservationId}`);
    
    if (!reservation) {
      return c.json({ 
        success: false, 
        error: "Reservation not found" 
      }, 404);
    }
    
    if (reservation.status !== 'active') {
      return c.json({ 
        success: false, 
        error: "Only active reservations can be cancelled" 
      }, 400);
    }
    
    // Update reservation
    reservation.status = 'cancelled';
    reservation.cancelledAt = Date.now();
    
    await kv.set(`reservation:${reservationId}`, reservation);
    
    // Return inventory
    const inventoryKey = `inventory:${reservation.businessId}`;
    const inventory = await kv.get(inventoryKey);
    if (inventory) {
      inventory.available += 1;
      inventory.reserved = Math.max(0, (inventory.reserved || 0) - 1);
      await kv.set(inventoryKey, inventory);
    }
    
    return c.json({ 
      success: true, 
      reservation,
      message: "Reservation cancelled successfully" 
    });
  } catch (error) {
    console.log("Error cancelling reservation:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// INVENTORY MANAGEMENT (for you to manage manually)
// ============================================

// Set business inventory
app.post("/make-server-efcc1648/inventory", async (c) => {
  try {
    const body = await c.req.json();
    const { businessId, available, month } = body;
    
    if (!businessId || available === undefined) {
      return c.json({ 
        success: false, 
        error: "Missing required fields: businessId, available" 
      }, 400);
    }
    
    const inventoryKey = `inventory:${businessId}`;
    const inventory = {
      businessId,
      available: parseInt(available),
      reserved: 0,
      redeemed: 0,
      month: month || new Date().toISOString().substring(0, 7), // YYYY-MM
      updatedAt: Date.now(),
    };
    
    await kv.set(inventoryKey, inventory);
    
    return c.json({ 
      success: true, 
      inventory,
      message: "Inventory updated successfully" 
    });
  } catch (error) {
    console.log("Error updating inventory:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get business inventory
app.get("/make-server-efcc1648/inventory/:businessId", async (c) => {
  try {
    const businessId = c.req.param("businessId");
    const inventoryKey = `inventory:${businessId}`;
    const inventory = await kv.get(inventoryKey);
    
    if (!inventory) {
      return c.json({ 
        success: true, 
        inventory: {
          businessId,
          available: 0,
          reserved: 0,
          redeemed: 0,
        }
      });
    }
    
    return c.json({ 
      success: true, 
      inventory 
    });
  } catch (error) {
    console.log("Error fetching inventory:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// B2B ANALYTICS ENDPOINTS
// ============================================

// Get brand overview stats
app.get("/make-server-efcc1648/analytics/:brandId/overview", async (c) => {
  try {
    const brandId = c.req.param("brandId");
    
    // Get all scans for this brand
    const brandScans = await kv.getByPrefix(`scan:brand:${brandId}`);
    
    // Get recent daily stats (last 30 days)
    const today = new Date();
    const dailyStats = [];
    
    for (let i = 0; i < 30; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const stats = await kv.get(`stats:brand:${brandId}:${dateStr}`);
      if (stats) {
        dailyStats.push(stats);
      }
    }
    
    // Calculate totals
    const totalScans = brandScans.length;
    const totalCredits = dailyStats.reduce((sum, day) => sum + (day.totalCredits || 0), 0);
    const scansThisWeek = dailyStats.slice(0, 7).reduce((sum, day) => sum + (day.totalScans || 0), 0);
    const scansThisMonth = dailyStats.reduce((sum, day) => sum + (day.totalScans || 0), 0);
    
    return c.json({
      success: true,
      overview: {
        totalScans,
        totalCredits,
        scansThisWeek,
        scansThisMonth,
        dailyStats: dailyStats.reverse(), // Oldest to newest
      }
    });
  } catch (error) {
    console.log("Error fetching brand overview:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get geographic distribution
app.get("/make-server-efcc1648/analytics/:brandId/geography", async (c) => {
  try {
    const brandId = c.req.param("brandId");
    const days = parseInt(c.req.query("days") || "30");
    
    const today = new Date();
    const cityTotals: Record<string, number> = {};
    const areaTotals: Record<string, number> = {};
    
    for (let i = 0; i < days; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const stats = await kv.get(`stats:brand:${brandId}:${dateStr}`);
      
      if (stats) {
        // Aggregate cities
        Object.entries(stats.scansByCityMap || {}).forEach(([city, count]) => {
          cityTotals[city] = (cityTotals[city] || 0) + (count as number);
        });
        
        // Count unique areas
        (stats.uniqueAreas || []).forEach((area: string) => {
          areaTotals[area] = (areaTotals[area] || 0) + 1;
        });
      }
    }
    
    return c.json({
      success: true,
      geography: {
        cities: cityTotals,
        topAreas: Object.entries(areaTotals)
          .sort(([, a], [, b]) => (b as number) - (a as number))
          .slice(0, 10)
          .map(([area, count]) => ({ area, count })),
      }
    });
  } catch (error) {
    console.log("Error fetching geography data:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get product performance
app.get("/make-server-efcc1648/analytics/:brandId/products", async (c) => {
  try {
    const brandId = c.req.param("brandId");
    
    // Get all products for this brand
    const allProducts = await kv.getByPrefix("product:");
    const brandProducts = allProducts.filter((p: any) => {
      const pBrandId = p.brandId || p.brand.toLowerCase().replace(/\s+/g, '-');
      return pBrandId === brandId;
    });
    
    // Get scan counts for each product
    const productStats = await Promise.all(
      brandProducts.map(async (product: any) => {
        const scans = await kv.getByPrefix(`scan:sku:${product.sku}`);
        return {
          sku: product.sku,
          name: product.name,
          category: product.category,
          totalScans: scans.length,
          creditsPerScan: product.credits,
          totalCredits: scans.length * product.credits,
        };
      })
    );
    
    // Sort by total scans
    productStats.sort((a, b) => b.totalScans - a.totalScans);
    
    return c.json({
      success: true,
      products: productStats,
    });
  } catch (error) {
    console.log("Error fetching product performance:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Health check endpoint
app.get("/make-server-efcc1648/health", (c) => {
  return c.json({ status: "ok" });
});

Deno.serve(app.fetch);