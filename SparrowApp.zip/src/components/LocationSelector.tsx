import { MapPin, X, Globe2, ChevronLeft } from 'lucide-react';
import { useState, useEffect } from 'react';
import { googleMapsApiKey } from '../utils/supabase/info';

interface LocationSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocation: string;
  onLocationChange: (location: string) => void;
}

// Global locations organized by country
const COUNTRIES = [
  {
    id: 'india',
    name: 'India',
    flag: '🇮🇳',
    lat: 20.5937,
    lng: 78.9629,
    cities: [
      { id: 'mumbai', name: 'Mumbai', region: 'Maharashtra', lat: 19.0760, lng: 72.8777 },
      { id: 'delhi', name: 'Delhi', region: 'NCR', lat: 28.6139, lng: 77.2090 },
      { id: 'bangalore', name: 'Bangalore', region: 'Karnataka', lat: 12.9716, lng: 77.5946 },
      { id: 'chennai', name: 'Chennai', region: 'Tamil Nadu', lat: 13.0827, lng: 80.2707 },
      { id: 'kolkata', name: 'Kolkata', region: 'West Bengal', lat: 22.5726, lng: 88.3639 },
      { id: 'hyderabad', name: 'Hyderabad', region: 'Telangana', lat: 17.3850, lng: 78.4867 },
      { id: 'pune', name: 'Pune', region: 'Maharashtra', lat: 18.5204, lng: 73.8567 },
      { id: 'ahmedabad', name: 'Ahmedabad', region: 'Gujarat', lat: 23.0225, lng: 72.5714 },
    ]
  },
  {
    id: 'usa',
    name: 'United States',
    flag: '🇺🇸',
    lat: 37.0902,
    lng: -95.7129,
    cities: [
      { id: 'new-york', name: 'New York', region: 'New York', lat: 40.7128, lng: -74.0060 },
      { id: 'los-angeles', name: 'Los Angeles', region: 'California', lat: 34.0522, lng: -118.2437 },
      { id: 'chicago', name: 'Chicago', region: 'Illinois', lat: 41.8781, lng: -87.6298 },
      { id: 'houston', name: 'Houston', region: 'Texas', lat: 29.7604, lng: -95.3698 },
      { id: 'phoenix', name: 'Phoenix', region: 'Arizona', lat: 33.4484, lng: -112.0740 },
      { id: 'philadelphia', name: 'Philadelphia', region: 'Pennsylvania', lat: 39.9526, lng: -75.1652 },
      { id: 'san-antonio', name: 'San Antonio', region: 'Texas', lat: 29.4241, lng: -98.4936 },
      { id: 'san-diego', name: 'San Diego', region: 'California', lat: 32.7157, lng: -117.1611 },
    ]
  },
  {
    id: 'uk',
    name: 'United Kingdom',
    flag: '🇬🇧',
    lat: 55.3781,
    lng: -3.4360,
    cities: [
      { id: 'london', name: 'London', region: 'England', lat: 51.5074, lng: -0.1278 },
      { id: 'manchester', name: 'Manchester', region: 'England', lat: 53.4808, lng: -2.2426 },
      { id: 'birmingham', name: 'Birmingham', region: 'England', lat: 52.4862, lng: -1.8904 },
      { id: 'glasgow', name: 'Glasgow', region: 'Scotland', lat: 55.8642, lng: -4.2518 },
      { id: 'liverpool', name: 'Liverpool', region: 'England', lat: 53.4084, lng: -2.9916 },
      { id: 'edinburgh', name: 'Edinburgh', region: 'Scotland', lat: 55.9533, lng: -3.1883 },
      { id: 'bristol', name: 'Bristol', region: 'England', lat: 51.4545, lng: -2.5879 },
      { id: 'leeds', name: 'Leeds', region: 'England', lat: 53.8008, lng: -1.5491 },
    ]
  },
  {
    id: 'germany',
    name: 'Germany',
    flag: '🇩🇪',
    lat: 51.1657,
    lng: 10.4515,
    cities: [
      { id: 'berlin', name: 'Berlin', region: 'Berlin', lat: 52.5200, lng: 13.4050 },
      { id: 'munich', name: 'Munich', region: 'Bavaria', lat: 48.1351, lng: 11.5820 },
      { id: 'frankfurt', name: 'Frankfurt', region: 'Hesse', lat: 50.1109, lng: 8.6821 },
      { id: 'hamburg', name: 'Hamburg', region: 'Hamburg', lat: 53.5511, lng: 9.9937 },
      { id: 'cologne', name: 'Cologne', region: 'North Rhine-Westphalia', lat: 50.9375, lng: 6.9603 },
      { id: 'stuttgart', name: 'Stuttgart', region: 'Baden-Württemberg', lat: 48.7758, lng: 9.1829 },
    ]
  },
  {
    id: 'france',
    name: 'France',
    flag: '🇫🇷',
    lat: 46.2276,
    lng: 2.2137,
    cities: [
      { id: 'paris', name: 'Paris', region: 'Île-de-France', lat: 48.8566, lng: 2.3522 },
      { id: 'marseille', name: 'Marseille', region: 'Provence-Alpes-Côte d\'Azur', lat: 43.2965, lng: 5.3698 },
      { id: 'lyon', name: 'Lyon', region: 'Auvergne-Rhône-Alpes', lat: 45.7640, lng: 4.8357 },
      { id: 'toulouse', name: 'Toulouse', region: 'Occitanie', lat: 43.6047, lng: 1.4442 },
      { id: 'nice', name: 'Nice', region: 'Provence-Alpes-Côte d\'Azur', lat: 43.7102, lng: 7.2620 },
      { id: 'bordeaux', name: 'Bordeaux', region: 'Nouvelle-Aquitaine', lat: 44.8378, lng: -0.5792 },
    ]
  },
  {
    id: 'canada',
    name: 'Canada',
    flag: '🇨🇦',
    lat: 56.1304,
    lng: -106.3468,
    cities: [
      { id: 'toronto', name: 'Toronto', region: 'Ontario', lat: 43.6532, lng: -79.3832 },
      { id: 'vancouver', name: 'Vancouver', region: 'British Columbia', lat: 49.2827, lng: -123.1207 },
      { id: 'montreal', name: 'Montreal', region: 'Quebec', lat: 45.5017, lng: -73.5673 },
      { id: 'calgary', name: 'Calgary', region: 'Alberta', lat: 51.0447, lng: -114.0719 },
      { id: 'ottawa', name: 'Ottawa', region: 'Ontario', lat: 45.4215, lng: -75.6972 },
      { id: 'edmonton', name: 'Edmonton', region: 'Alberta', lat: 53.5461, lng: -113.4938 },
    ]
  },
  {
    id: 'australia',
    name: 'Australia',
    flag: '🇦🇺',
    lat: -25.2744,
    lng: 133.7751,
    cities: [
      { id: 'sydney', name: 'Sydney', region: 'New South Wales', lat: -33.8688, lng: 151.2093 },
      { id: 'melbourne', name: 'Melbourne', region: 'Victoria', lat: -37.8136, lng: 144.9631 },
      { id: 'brisbane', name: 'Brisbane', region: 'Queensland', lat: -27.4698, lng: 153.0251 },
      { id: 'perth', name: 'Perth', region: 'Western Australia', lat: -31.9505, lng: 115.8605 },
      { id: 'adelaide', name: 'Adelaide', region: 'South Australia', lat: -34.9285, lng: 138.6007 },
    ]
  },
  {
    id: 'japan',
    name: 'Japan',
    flag: '🇯🇵',
    lat: 36.2048,
    lng: 138.2529,
    cities: [
      { id: 'tokyo', name: 'Tokyo', region: 'Kanto', lat: 35.6762, lng: 139.6503 },
      { id: 'osaka', name: 'Osaka', region: 'Kansai', lat: 34.6937, lng: 135.5023 },
      { id: 'kyoto', name: 'Kyoto', region: 'Kansai', lat: 35.0116, lng: 135.7681 },
      { id: 'yokohama', name: 'Yokohama', region: 'Kanto', lat: 35.4437, lng: 139.6380 },
      { id: 'nagoya', name: 'Nagoya', region: 'Chubu', lat: 35.1815, lng: 136.9066 },
      { id: 'fukuoka', name: 'Fukuoka', region: 'Kyushu', lat: 33.5904, lng: 130.4017 },
    ]
  }
];

// Flatten all cities for quick lookup
const ALL_CITIES = COUNTRIES.flatMap(country => 
  country.cities.map(city => ({ ...city, countryId: country.id, countryName: country.name, countryFlag: country.flag }))
);

// Generate static map URL using Google Maps Static API
const generateGoogleMapUrl = (lat: number, lng: number, zoom: number, width: number = 600, height: number = 300, markers?: Array<{ lat: number; lng: number }>) => {
  const apiKey = googleMapsApiKey;
  if (!apiKey) {
    console.warn('Google Maps API key not found');
    return '';
  }

  const baseUrl = 'https://maps.googleapis.com/maps/api/staticmap';
  let url = `${baseUrl}?center=${lat},${lng}&zoom=${zoom}&size=${width}x${height}&scale=2&maptype=roadmap`;
  
  // Add markers if provided
  if (markers && markers.length > 0) {
    const markerString = markers.map(m => `${m.lat},${m.lng}`).join('|');
    url += `&markers=color:red|${markerString}`;
  }
  
  url += `&key=${apiKey}`;
  
  return url;
};

// World map view coordinates
const WORLD_VIEW = { lat: 30, lng: 20, zoom: 1 };

export function LocationSelector({ isOpen, onClose, currentLocation, onLocationChange }: LocationSelectorProps) {
  const [selectedLocation, setSelectedLocation] = useState(currentLocation);
  const [isAnimating, setIsAnimating] = useState(false);
  const [view, setView] = useState<'map' | 'country' | 'cities'>('map');
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setIsAnimating(true);
      setView('map');
      setSelectedCountry(null);
    }
  }, [isOpen]);

  const handleLocationSelect = (locationId: string) => {
    setSelectedLocation(locationId);
    onLocationChange(locationId);
    // Close after a brief delay to show selection
    setTimeout(() => {
      handleClose();
    }, 300);
  };

  const handleClose = () => {
    setIsAnimating(false);
    setTimeout(() => {
      onClose();
    }, 300);
  };

  const handleCountrySelect = (countryId: string) => {
    setSelectedCountry(countryId);
    setView('cities');
  };

  const handleBackToMap = () => {
    setView('map');
    setSelectedCountry(null);
  };

  // Get selected city info
  const selectedCity = ALL_CITIES.find(city => city.id === selectedLocation);
  const currentCity = ALL_CITIES.find(city => city.id === currentLocation);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop with blur */}
      <div 
        className={`fixed inset-0 z-50 bg-black/40 backdrop-blur-md transition-opacity duration-300 ${
          isAnimating ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={handleClose}
      />

      {/* Central Modal with Island Animation */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
        <div
          className={`
            w-full max-w-md bg-white rounded-[2rem] shadow-2xl pointer-events-auto
            transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)]
            ${isAnimating 
              ? 'opacity-100 scale-100 translate-y-0' 
              : 'opacity-0 scale-75 -translate-y-8'
            }
          `}
          style={{
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.05)',
            maxHeight: '85vh',
            display: 'flex',
            flexDirection: 'column'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header with glassmorphism */}
          <div className="relative px-6 pt-6 pb-4 flex-shrink-0">
            <div className="flex items-center justify-between">
              {/* Breadcrumb Navigation */}
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <button
                  onClick={handleClose}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                  style={{ fontSize: '15px', fontWeight: '600' }}
                >
                  Location
                </button>
                
                {view === 'cities' && selectedCountry && (
                  <>
                    <ChevronLeft className="w-4 h-4 text-muted-foreground rotate-180 flex-shrink-0" />
                    <button
                      onClick={handleBackToMap}
                      className="text-muted-foreground hover:text-foreground transition-colors truncate"
                      style={{ fontSize: '15px', fontWeight: '600' }}
                    >
                      {COUNTRIES.find(c => c.id === selectedCountry)?.name}
                    </button>
                  </>
                )}
                
                {selectedCity && (
                  <>
                    <ChevronLeft className="w-4 h-4 text-muted-foreground rotate-180 flex-shrink-0" />
                    <span 
                      className="text-foreground truncate"
                      style={{ fontSize: '15px', fontWeight: '700' }}
                    >
                      {selectedCity.name}
                    </span>
                  </>
                )}
              </div>

              {/* Close Button */}
              <button
                onClick={handleClose}
                className="w-9 h-9 rounded-full bg-black/5 flex items-center justify-center transition-all duration-200 active:scale-95 hover:bg-black/10 flex-shrink-0 ml-3"
              >
                <X className="w-4.5 h-4.5 text-foreground/60" />
              </button>
            </div>
          </div>

          {/* Divider */}
          <div className="px-6 flex-shrink-0">
            <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
          </div>

          {/* Content Area - Scrollable */}
          <div className="px-6 pt-5 pb-6 overflow-y-auto flex-1">
            {/* World Map View - Country Selection */}
            {view === 'map' && (
              <div className="space-y-3">
                {/* Static OpenStreetMap - World View */}
                <div className="relative w-full aspect-[2/1] rounded-[1.5rem] mb-4 overflow-hidden border border-border/30 bg-gray-100">
                  <img
                    src={generateGoogleMapUrl(WORLD_VIEW.lat, WORLD_VIEW.lng, WORLD_VIEW.zoom, 600, 300)}
                    alt="World Map"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  {/* Overlay gradient for aesthetic */}
                  <div 
                    className="absolute inset-0 pointer-events-none"
                    style={{
                      background: 'linear-gradient(to bottom, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 50%, rgba(0,0,0,0.05) 100%)'
                    }}
                  />
                </div>

                {/* Country List */}
                <div className="grid grid-cols-1 gap-2.5">
                  {COUNTRIES.map((country, index) => {
                    const hasCities = country.cities.length > 0;
                    const hasSelectedCity = country.cities.some(city => city.id === currentLocation);

                    return (
                      <button
                        key={country.id}
                        onClick={() => handleCountrySelect(country.id)}
                        disabled={!hasCities}
                        className={`
                          relative flex items-center gap-3 p-3.5 rounded-[1.2rem] 
                          transition-all duration-300 active:scale-[0.98] border-2 group text-left
                          ${isAnimating ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}
                          ${hasSelectedCity
                            ? 'bg-primary/8 border-primary shadow-[0_4px_12px_rgba(255,153,51,0.15)]' 
                            : 'bg-white border-border/40 hover:border-primary/40 hover:bg-primary/5 hover:shadow-[0_2px_8px_rgba(0,0,0,0.04)]'
                          }
                          ${!hasCities && 'opacity-50 cursor-not-allowed'}
                        `}
                        style={{
                          transitionDelay: isAnimating ? `${index * 40}ms` : '0ms',
                        }}
                      >
                        <div className="text-4xl flex-shrink-0">{country.flag}</div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span 
                              style={{ 
                                fontSize: '15px', 
                                fontWeight: hasSelectedCity ? '700' : '600',
                                letterSpacing: '-0.01em'
                              }}
                            >
                              {country.name}
                            </span>
                            {hasSelectedCity && (
                              <span 
                                className="px-1.5 py-0.5 rounded-full bg-primary text-white flex-shrink-0"
                                style={{ 
                                  fontSize: '9px', 
                                  fontWeight: '800',
                                  letterSpacing: '0.02em'
                                }}
                              >
                                ACTIVE
                              </span>
                            )}
                          </div>
                          <p 
                            className="text-muted-foreground" 
                            style={{ fontSize: '12px', marginTop: '1px' }}
                          >
                            {country.cities.length} {country.cities.length === 1 ? 'city' : 'cities'} available
                          </p>
                        </div>

                        <ChevronLeft className="w-5 h-5 text-foreground/40 rotate-180 flex-shrink-0" />
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Cities View */}
            {view === 'cities' && selectedCountry && (
              <div className="space-y-3">
                {/* Static OpenStreetMap - Country View with City Markers */}
                <div className="relative w-full aspect-[2/1] rounded-[1.5rem] mb-4 overflow-hidden border border-border/30 bg-gray-100">
                  {(() => {
                    const country = COUNTRIES.find(c => c.id === selectedCountry);
                    if (!country) return null;
                    
                    // Generate map with city markers
                    const cityMarkers = country.cities.map(city => ({ lat: city.lat, lng: city.lng }));
                    const mapUrl = generateGoogleMapUrl(country.lat, country.lng, 5, 600, 300, cityMarkers);
                    
                    return (
                      <>
                        <img
                          src={mapUrl}
                          alt={`${country.name} Map`}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                        {/* Overlay gradient for aesthetic */}
                        <div 
                          className="absolute inset-0 pointer-events-none"
                          style={{
                            background: 'linear-gradient(to bottom, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 50%, rgba(0,0,0,0.05) 100%)'
                          }}
                        />
                      </>
                    );
                  })()}
                </div>

                {/* Cities Grid */}
                <div className="grid grid-cols-2 gap-2.5">{COUNTRIES.find(c => c.id === selectedCountry)?.cities.map((city, index) => {
                  const isSelected = selectedLocation === city.id;
                  const isCurrent = currentLocation === city.id;

                  return (
                    <button
                      key={city.id}
                      onClick={() => handleLocationSelect(city.id)}
                      className={`
                        relative flex items-center gap-2.5 p-3 rounded-[1.2rem] 
                        transition-all duration-300 active:scale-[0.96] border-2 group
                        ${isAnimating ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}
                        ${isSelected 
                          ? 'bg-primary/8 border-primary shadow-[0_4px_12px_rgba(255,153,51,0.15)]' 
                          : 'bg-white border-border/40 hover:border-primary/40 hover:bg-primary/5 hover:shadow-[0_2px_8px_rgba(0,0,0,0.04)]'
                        }
                      `}
                      style={{
                        transitionDelay: isAnimating ? `${index * 40}ms` : '0ms',
                      }}
                    >
                      {/* Subtle gradient overlay on hover */}
                      <div 
                        className={`
                          absolute inset-0 rounded-[1.2rem] opacity-0 group-hover:opacity-100 transition-opacity duration-300
                          ${!isSelected && 'pointer-events-none'}
                        `}
                        style={{
                          background: 'linear-gradient(135deg, rgba(255,153,51,0.03) 0%, rgba(255,153,51,0.01) 100%)',
                        }}
                      />
                      
                      <div className={`
                        relative w-8 h-8 rounded-[0.7rem] flex items-center justify-center transition-all duration-300 flex-shrink-0
                        ${isSelected 
                          ? 'bg-primary text-white shadow-[0_2px_8px_rgba(255,153,51,0.3)]' 
                          : 'bg-muted/50 text-foreground/60 group-hover:bg-muted'
                        }
                      `}>
                        <MapPin className="w-4 h-4" />
                      </div>
                      
                      <div className="text-left flex-1 min-w-0 relative z-10">
                        <div className="flex items-center gap-1.5">
                          <span 
                            style={{ 
                              fontSize: '14px', 
                              fontWeight: isSelected ? '700' : '600',
                              letterSpacing: '-0.01em'
                            }}
                            className="truncate"
                          >
                            {city.name}
                          </span>
                          {isCurrent && (
                            <span 
                              className="px-1.5 py-0.5 rounded-full bg-primary text-white flex-shrink-0"
                              style={{ 
                                fontSize: '9px', 
                                fontWeight: '800',
                                letterSpacing: '0.02em'
                              }}
                            >
                              NOW
                            </span>
                          )}
                        </div>
                        <p 
                          className="text-muted-foreground truncate" 
                          style={{ fontSize: '11px', marginTop: '1px', letterSpacing: '-0.01em' }}
                        >
                          {city.region}
                        </p>
                      </div>

                      {isSelected && (
                        <div 
                          className="w-5 h-5 rounded-full bg-primary flex items-center justify-center flex-shrink-0 relative z-10 animate-scale-in"
                          style={{
                            boxShadow: '0 2px 8px rgba(255,153,51,0.3)',
                          }}
                        >
                          <svg
                            className="w-3 h-3 text-white"
                            fill="none"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="3"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                      )}
                    </button>
                  );
                })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}