import * as React from "react";
import { Slot } from "@radix-ui/react-slot@1.1.2";
import { cva, type VariantProps } from "class-variance-authority@0.7.1";

import { cn } from "./utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-all duration-200 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive relative overflow-hidden active:scale-[0.98] active:transition-transform active:duration-100",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_2px_8px_rgba(255,153,51,0.25)] hover:shadow-[0_4px_16px_rgba(255,153,51,0.35)] rounded-[1.5rem] active:shadow-[0_1px_4px_rgba(255,153,51,0.3)]",
        destructive:
          "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60 shadow-[0_2px_8px_rgba(220,20,60,0.25)] hover:shadow-[0_4px_16px_rgba(220,20,60,0.35)] rounded-[1.5rem] active:shadow-[0_1px_4px_rgba(220,20,60,0.3)]",
        outline:
          "border-2 border-primary bg-background text-foreground hover:bg-primary/5 hover:border-primary/80 dark:bg-input/30 dark:border-input dark:hover:bg-input/50 rounded-[1.5rem] shadow-[0_1px_3px_rgba(0,0,0,0.08)] hover:shadow-[0_2px_8px_rgba(255,153,51,0.15)]",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-[0_2px_8px_rgba(5,150,105,0.25)] hover:shadow-[0_4px_16px_rgba(5,150,105,0.35)] rounded-[1.5rem] active:shadow-[0_1px_4px_rgba(5,150,105,0.3)]",
        ghost:
          "hover:bg-accent/10 hover:text-accent-foreground dark:hover:bg-accent/50 rounded-[1.5rem]",
        link: "text-primary underline-offset-4 hover:underline rounded-none",
      },
      size: {
        default: "h-11 px-5 py-2.5 has-[>svg]:px-4",
        sm: "h-9 gap-1.5 px-3.5 has-[>svg]:px-3",
        lg: "h-12 px-6 has-[>svg]:px-5",
        icon: "size-11",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  }) {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { Button, buttonVariants };