import { Dialog, DialogContent, DialogTitle, DialogDescription } from './ui/dialog';
import { Package, Truck, Users, Sparkles } from 'lucide-react';

interface HowSparrowWorksModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function HowSparrowWorksModal({ open, onOpenChange }: HowSparrowWorksModalProps) {
  const instructions = [
    {
      icon: <Sparkles className="w-5 h-5" />,
      title: 'Credits Based on Quality',
      description: 'Products in good condition earn more credits. Broken, dirty, or damaged items earn fewer credits.',
      color: '#ff9933'
    },
    {
      icon: <Truck className="w-5 h-5" />,
      title: 'Automatic Pickup',
      description: 'Once you scan a product, pickup is automatically scheduled for the next day.',
      color: '#059669'
    },
    {
      icon: <Package className="w-5 h-5" />,
      title: 'Circular Economy',
      description: 'We send products back to brands or transform disposables into long-life products.',
      color: '#4169e1'
    },
    {
      icon: <Users className="w-5 h-5" />,
      title: 'Empowering Workers',
      description: 'All former informal waste workers are now official Sparrow employees with benefits.',
      color: '#ffd700'
    }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogTitle>How Sparrow Works</DialogTitle>
        <DialogDescription>
          Learn about our impact and process
        </DialogDescription>

        {/* Instructions */}
        <div className="space-y-3 py-4">
          {instructions.map((item, index) => (
            <div
              key={index}
              className="flex gap-3 p-3 rounded-[1.5rem] bg-muted/50 border border-border/50"
            >
              <div
                className="w-10 h-10 min-w-[40px] rounded-full flex items-center justify-center"
                style={{ backgroundColor: `${item.color}15` }}
              >
                <div style={{ color: item.color }}>
                  {item.icon}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-foreground mb-1" style={{ fontSize: '14px', fontWeight: '600' }}>
                  {item.title}
                </h4>
                <p className="text-muted-foreground" style={{ fontSize: '12px', lineHeight: '1.5' }}>
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
