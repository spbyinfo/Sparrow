
  # SBPY EPR Dashboard Pilot (Copy)

  This is a code bundle for SBPY EPR Dashboard Pilot (Copy). The original project is available at https://www.figma.com/design/2wdrrz0JiyS0oPdLB5oNKA/SBPY-EPR-Dashboard-Pilot--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  